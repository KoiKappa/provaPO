package prova;
import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        try (Scanner x=new Scanner(System.in)){
            
        }
        
    }
}
